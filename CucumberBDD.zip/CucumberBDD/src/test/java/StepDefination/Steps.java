package StepDefination;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Steps{
	
	WebDriver driver;
	
	@Before
	public void setUp() {
		String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.chrome.driver",projectPath+"/Drivers/ChromeDriver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Given("Navigate to the Login page")
	public void navigate_to_the_login_page() {
		driver.get("https://practicetestautomation.com/practice-test-login/");
	}

	@When("User Login with a valid username and password")
	public void user_login_with_a_valid_username_and_password() throws AWTException, InterruptedException {
		try {
		driver.findElement(By.name("username")).sendKeys("student");
		driver.findElement(By.name("password")).sendKeys("Password123");
		driver.findElement(By.id("submit")).click();
	}catch(Exception e){
		System.out.println(e);
		}
	}

	@Then("User should be logged in successfully")
	public void user_should_be_logged_in_successfully() {
		try {
			if(driver.findElement(By.xpath("//h1[@class='post-title']")).getText().contains("Successfully")) 
				System.out.println("User Logged in Successfulqly");
		}catch(Exception e) {
			System.out.println(e);
		}	    
	}

	//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Background.feature>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	
	@Given("launch URL")
	public void launch_url() {
		driver.get("https://practicetestautomation.com/practice-test-login/");
	}

	@When("User enter invalid username and valid password")
	public void user_enter_invalid_username_and_valid_password() {
		driver.findElement(By.name("username")).sendKeys(" ");
		driver.findElement(By.name("password")).sendKeys("Password123");
		driver.findElement(By.id("submit")).click();
	}

	@Then("Verify login is failed")
	public void verify_login_is_failed() {
		try {
			if(driver.findElement(By.id("error")).getText().contains("invalid!")) 
				System.out.println("User Login Failed");
		}catch(Exception e) {
			System.out.println(e);
		}	
	   
	}
	
	//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> parameterization >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	
	@When("User Login with a valid {string} and {string}")
	public void user_login_with_a_valid_and(String string, String string2) {
		try {
			driver.findElement(By.name("username")).sendKeys(string);
			driver.findElement(By.name("password")).sendKeys(string2);
			driver.findElement(By.id("submit")).click();
		}catch(Exception e){
			System.out.println(e);
			}
		}

	
	@When("^User Login with a valid (.*) and (.*)$")
	public void user_login_with_a_valid_username_and_password(String username,String password) {
		System.out.println(username);
		driver.findElement(By.name("username")).sendKeys(username);
		System.out.println(password);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.id("submit")).click();
	}
	
	@After
	public void closeBrowser() {
		driver.close();
	}

	}


